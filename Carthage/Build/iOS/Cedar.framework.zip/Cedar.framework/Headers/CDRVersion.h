#import <Foundation/Foundation.h>

static NSString *CDRVersion = @"1.0";
