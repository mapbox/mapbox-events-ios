#import <Foundation/Foundation.h>
#import "CDRDefaultReporter.h"

@interface CDRTeamCityReporter : CDRDefaultReporter {

}

@end
