#import <Foundation/Foundation.h>
#import "CDRBufferedDefaultReporter.h"

@interface CDRColorizedReporter : CDRBufferedDefaultReporter

@end
